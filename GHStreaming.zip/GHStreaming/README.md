# MeshReceivingUnityClient
Unity file to receive streamed mesh binary data.

## Unity Version
5.6.0f3

## Dependencies

- [Socket.IO for Unity](https://www.assetstore.unity3d.com/en/#!/content/21721)
- [ZeroFormatter.Unity](https://github.com/neuecc/ZeroFormatter)
- [Json.NET](http://www.newtonsoft.com/json)
