﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class UDPSendingIDPoRo : MonoBehaviour
{


    public string IP;
    public int port;
    public string msg = "";

    // "connection" things
    IPEndPoint remoteEndPoint;
    UdpClient client;

    // Use this for initialization
    void Start()
    {
        remoteEndPoint = new IPEndPoint(IPAddress.Parse(IP), port);
        client = new UdpClient();
        // status
        print("Sending to " + IP + " : " + port);

    }

    // Update is called once per frame
    void Update()
    {
        sendString(msg);
    }
    // a funtion to send data via UDP
    private void sendString(string message)
    {
        try
        {


            // encode string to UTF8-coded bytes
            byte[] data = Encoding.UTF8.GetBytes(message);

            // send the data
            client.Send(data, data.Length, remoteEndPoint);

        }
        catch (Exception err)
        {
            print(err.ToString());
        }
    }


}
