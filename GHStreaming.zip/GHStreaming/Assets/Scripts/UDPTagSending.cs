﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class UDPTagSending : MonoBehaviour
{


    public string IP;
    public int port;
    public List<GameObject> MyPrefab = new List<GameObject>();
    public GameObject[] prefabTag;
    // "connection" things
    IPEndPoint remoteEndPoint;
    UdpClient client;

    // Use this for initialization
    void Start()
    {

        IP = "192.168.211.145";
        port = 8055;


        remoteEndPoint = new IPEndPoint(IPAddress.Parse(IP), port);
        client = new UdpClient();

        // status
        print("Sending to " + IP + " : " + port);
    }

    // Update is called once per frame
    void Update()
    {
        String msg = "";
        
        prefabTag = GameObject.FindGameObjectsWithTag("Storage");
        print("there are udp box with number of:" + prefabTag.Length);
        for (int i = 0; i < prefabTag.Length; i++)
        {
            msg = msg + prefabTag[i].gameObject.transform.position.x.ToString() + "," + prefabTag[i].gameObject.transform.position.z.ToString() + "," + prefabTag[i].gameObject.transform.position.y.ToString() + ";";
            msg = msg + prefabTag[i].gameObject.transform.localScale.x.ToString() + "," + prefabTag[i].gameObject.transform.localScale.z.ToString() + "," + prefabTag[i].gameObject.transform.localScale.y.ToString() + ";";
            msg = msg + prefabTag[i].gameObject.transform.rotation.eulerAngles.x.ToString() + "," + prefabTag[i].gameObject.transform.rotation.eulerAngles.z.ToString() + "," + prefabTag[i].gameObject.transform.rotation.eulerAngles.y.ToString() + ";";
            print(i);
        }
        print(msg);
        sendString(msg);
    }

    // a funtion to send data via UDP
    private void sendString(string message)
    {
        try
        {


            // encode string to UTF8-coded bytes
            byte[] data = Encoding.UTF8.GetBytes(message);

            // send the data
            client.Send(data, data.Length, remoteEndPoint);

        }
        catch (Exception err)
        {
            print(err.ToString());
        }
    }
}
