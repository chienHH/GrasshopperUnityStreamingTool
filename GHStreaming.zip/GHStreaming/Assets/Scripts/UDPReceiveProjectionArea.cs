﻿
/*
 
    -----------------------
    UDP-Receive (send to)
    -----------------------
https://forum.unity.com/threads/simple-udp-implementation-send-read-via-mono-c.15900/
Source Code Inspiration
 
*/
using UnityEngine;
using System.Collections;
using System.Collections.Generic;

using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class UDPReceiveProjectionArea : MonoBehaviour
{

    // receiving Thread
    Thread receiveThread;

    // udpclient object
    UdpClient client;

    // public
    // public string IP = "127.0.0.1"; default local
    public int port; // define > init

    // infos
    public string lastReceivedUDPPacket = "";
    public string allReceivedUDPPackets = ""; // clean up this from time to time!

    //ProjectionAreas Info
    public string projsrfArea; //Get the data from karamba

    private bool messageChange = false;

    // start from shell
    private static void Main()
    {
        UDPReceiveProjectionArea receiveObj = new UDPReceiveProjectionArea();
        receiveObj.init();

        string text = "";
        do
        {
            text = Console.ReadLine();
        }
        while (!text.Equals("exit"));
    }
    // start from unity3d
    public void Start()
    {

        init();
        parseDataToPoints(lastReceivedUDPPacket);
    }

    // OnGUI
    void OnGUI()
    {
        Rect rectObj = new Rect(40, 10, 200, 400);
        GUIStyle style = new GUIStyle();
        style.alignment = TextAnchor.UpperLeft;
        /*GUI.Box(rectObj, "# UDPReceive\n127.0.0.1 " + port + " #\n"
                    + "shell> nc -u 127.0.0.1 : " + port + " \n"
                    + "\nLast Packet: \n" + lastReceivedUDPPacket
                    + "\n\nAll Messages: \n" + allReceivedUDPPackets
                , style);*/
    }

    // init
    private void init()
    {
        // Endpunkt definieren, von dem die Nachrichten gesendet werden.
        //print("UDPSend.init()");

        // define port
        //port = 8050;

        // status
        //print("Sending to 127.0.0.1 : " + port);
        //print("Test-Sending to this Port: nc -u 127.0.0.1  " + port + "");


        // ----------------------------
        // Abhören
        // ----------------------------
        // Lokalen Endpunkt definieren (wo Nachrichten empfangen werden).
        // Einen neuen Thread für den Empfang eingehender Nachrichten erstellen.
        receiveThread = new Thread(
            new ThreadStart(ReceiveData));
        receiveThread.IsBackground = true;
        receiveThread.Start();

    }

    // receive thread
    private void ReceiveData()
    {

        client = new UdpClient(port);
        while (true)
        {

            try
            {
                // Bytes empfangen.
                IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, 0);
                byte[] data = client.Receive(ref anyIP);

                // Bytes mit der UTF8-Kodierung in das Textformat kodieren.
                string text = Encoding.UTF8.GetString(data);

                // Den abgerufenen Text anzeigen.
                //print(">> " + text);
                // latest UDPpacket
                lastReceivedUDPPacket = text;
                messageChange = true;
                // ....
                //allReceivedUDPPackets = allReceivedUDPPackets + text;

            }
            catch (Exception err)
            {
                print(err.ToString());
            }
        }
    }


    private void Update()
    {
        if (lastReceivedUDPPacket.Length > 0 && messageChange)
        {
            //print(lastReceivedUDPPacket);
            parseDataToPoints(lastReceivedUDPPacket);
            messageChange = false;
        }
        //parseDataToPoints(lastReceivedUDPPacket);
    }
    // getLatestUDPPacket
    // cleans up the rest
    public string getLatestUDPPacket()
    {
        allReceivedUDPPackets = "";
        return lastReceivedUDPPacket;
    }

    //Pharse string into point lists
    private void parseDataToPoints(string msg)
    {
            string[] data = msg.Split(' ');
        if (data.Length>0) { 
            projsrfArea = data[0];
        }
        else
        {
            projsrfArea = "0";
        }
        //print("Receive New Data From Karamba:"+ data[0]);
    }
}