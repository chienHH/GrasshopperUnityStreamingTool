﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

public class UDPSendingBox : MonoBehaviour
{


    public string IP;
    public int port;
    public List<GameObject> MyPrefab = new List<GameObject>();

    // "connection" things
    IPEndPoint remoteEndPoint;
    UdpClient client;

    // Use this for initialization
    void Start()
    {

        remoteEndPoint = new IPEndPoint(IPAddress.Parse(IP), port);
        client = new UdpClient();

        // status
        print("Sending to " + IP + " : " + port);
    }

    // Update is called once per frame
    void Update()
    {
        String msg = "E:";
        //print(MyPrefab.Count);
        for (int i =0; i<MyPrefab.Count; i++) { 
            //msg = msg + MyPrefab[i].gameObject.transform.position.x.ToString()+","+ MyPrefab[i].gameObject.transform.position.z.ToString() + "," + MyPrefab[i].gameObject.transform.position.y.ToString() + ";";
            String msgVertices = GetMeshVertices(i);
            String msgTriangles = GetMeshTriangles(i);
            msg = msg + msgVertices +"B:" + msgTriangles + "E:";

            //print(i);
        }
        sendString(msg);
    }
    // a funtion to send data via UDP
    private void sendString(string message)
    {
        try
        {


            // encode string to UTF8-coded bytes
            byte[] data = Encoding.UTF8.GetBytes(message);

            // send the data
            client.Send(data, data.Length, remoteEndPoint);

        }
        catch (Exception err)
        {
            print(err.ToString());
        }
    }

    //Get the vertices list of a mesh
    private string GetMeshVertices(int i) {

        Mesh myMesh = MyPrefab[i].GetComponent<MeshFilter>().sharedMesh;
        Vector3[] vertices = myMesh.vertices;
        string myVerticesString = "";

        for (int j=0;j<vertices.Length;j++)
        {
            Vector3 worldPt = MyPrefab[i].transform.TransformPoint(vertices[j]); //transform the pt into worldspace
            myVerticesString = myVerticesString + worldPt.ToString()+":";
        }

        return myVerticesString;

    }
    private string GetMeshTriangles(int i)
    {
        Mesh myMesh = MyPrefab[i].GetComponent<MeshFilter>().sharedMesh;
        int[] triangles = myMesh.triangles;
        string myFacesString = "T(";
        int tCount = 0;
        for (int j = 0; j < triangles.Length; j++)
        {
            myFacesString = myFacesString + triangles[j].ToString();
            if (tCount == 2)
            {
                tCount = 0;
                if (j == triangles.Length-1) {
                    myFacesString = myFacesString + ")" + ":";
                } else { 
                myFacesString = myFacesString + ")" + ":" + "T(";
                }
            }
            else
            {
                myFacesString = myFacesString + ";";
                tCount++;
            }
        }
        //print(myFacesString);
        return myFacesString;
    }

}
