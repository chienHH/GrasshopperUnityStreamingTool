﻿
/*
 
    -----------------------
    UDP-Receive (send to)
    -----------------------
https://forum.unity.com/threads/simple-udp-implementation-send-read-via-mono-c.15900/
Source Code Inspiration
 
*/
using Unity.MLAgents;
using Unity.MLAgents.Sensors;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.InputSystem;

using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using UnityEngine.UI;


namespace Brick
{
    public class UDPReceiveKaramba : MonoBehaviour
    {

        // receiving Thread
        Thread receiveThread;

        // udpclient object
        UdpClient client;

        

        public int portUtilization = 8065; // define > init
        public int portPtStress = 8067;
        // infos
        public string lastReceivedUDPPacket = "";
        public string allReceivedUDPPackets = ""; // clean up this from time to time!

        //Karamba Info
        public string karambaMsg = "0"; //Get the data from karamba

        [HideInInspector]
        public Vector3 stressPt;
        public string symmetryStr = "0";
        public string shadowContStr = "0";
        [HideInInspector]
        public bool messageChange = false;

        // start from shell
        private static void Main()
        {
            UDPReceiveKaramba receiveObj = new UDPReceiveKaramba();
            receiveObj.init();

            string text = "";
            do
            {
                text = Console.ReadLine();
            }
            while (!text.Equals("exit"));
        }
        // start from unity3d
        public void Start()
        {

            init();
            //parseDataToPoints(lastReceivedUDPPacket);
        }

        void OnGUI()
        {
            Rect rectObj = new Rect(40, 10, 200, 400);
            GUIStyle style = new GUIStyle();
            style.alignment = TextAnchor.UpperLeft;
        }

        // init
        private void init()
        {
            // Endpunkt definieren, von dem die Nachrichten gesendet werden.
            //print("UDPSend.init()");

            // define port
            //port = 8050;

            // status
            //print("Sending to 127.0.0.1 : " + port);
            //print("Test-Sending to this Port: nc -u 127.0.0.1  " + port + "");


            // ----------------------------
            // Abhören
            // ----------------------------
            // Lokalen Endpunkt definieren (wo Nachrichten empfangen werden).
            // Einen neuen Thread für den Empfang eingehender Nachrichten erstellen.
            receiveThread = new Thread(
            new ThreadStart(ReceiveData));
            receiveThread.IsBackground = true;
            receiveThread.Start();

        }

        // receive thread
        private void ReceiveData()
        {

            client = new UdpClient(portUtilization);
            while (true)
            {

                try
                {
                    // Bytes empfangen.
                    IPEndPoint anyIP = new IPEndPoint(IPAddress.Any, 0);
                    byte[] data = client.Receive(ref anyIP);

                    // Bytes mit der UTF8-Kodierung in das Textformat kodieren.
                    string text = Encoding.UTF8.GetString(data);

                    lastReceivedUDPPacket = text;
                    messageChange = true;

                }
                catch (Exception err)
                {
                    print(err.ToString());
                }
            }
        }


        private void Update()
        {
            /*if (lastReceivedUDPPacket.Length > 8 && messageChange)
            {
                Debug.Log("Message Change");
                parseDataToPoints(lastReceivedUDPPacket);
                messageChange = false;
            }*/
        }
        // getLatestUDPPacket
        // cleans up the rest

        public string getLatestUDPPacket()
        {
            allReceivedUDPPackets = "";
            return lastReceivedUDPPacket;
        }

        //Pharse string into point lists
        public void parseDataToPoints(string msg)
        {
            string[] data = msg.Split(';');
            karambaMsg = data[0];
            string[] strPos = data[1].Split(',');
            stressPt = new Vector3(float.Parse(strPos[0]), float.Parse(strPos[1]), float.Parse(strPos[2]));
            if(data[2]!= null) symmetryStr = data[2];
            if(data[3] != null) shadowContStr = data[3];
            //Debug.Log("SymStr::" + symmetryStr);
            //Debug.Log("ShaStr::" + shadowContStr);

        }

        private void OnDrawGizmos()
        {
            if (stressPt != null)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawSphere(stressPt, 1);
            }
        }
    }
}